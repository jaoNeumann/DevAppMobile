package com.hihi.avaliacaodevappmobile.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.hihi.avaliacaodevappmobile.Screens.Tela1
import com.hihi.avaliacaodevappmobile.Screens.Tela2
import com.hihi.avaliacaodevappmobile.Screens.Tela3

@Composable
fun AppNavigation(navController: NavHostController, modifier: Modifier = Modifier) {
    NavHost(navController = navController, startDestination = "tela1", modifier = modifier) {
        composable("tela1") { Tela1() }
        composable("tela2") { Tela2() }
        composable("tela3") { Tela3() }
    }
}
