package com.hihi.avaliacaodevappmobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.hihi.avaliacaodevappmobile.navigation.AppNavigation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            val drawerState = rememberDrawerState(DrawerValue.Closed)
            val coroutineScope = rememberCoroutineScope()

            // Use ModalDrawer para criar um menu lateral
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {DrawerMenu(navController, coroutineScope, drawerState)
                },
                content = {
                    // Conteúdo principal
                    Scaffold(
                        topBar = {
                            TopAppBar(
                                title = { Text("App com Menu Lateral") },
                                navigationIcon = {
                                    IconButton(onClick = {
                                        coroutineScope.launch {
                                            drawerState.open()
                                        }
                                    }) {
                                        Icon(Icons.Default.Menu, contentDescription = "Menu")
                                    }
                                }
                            )
                        }
                    ) { innerPadding ->AppNavigation(navController, Modifier.padding(innerPadding))
                    }
                }
            )
        }
    }
}

@Composable
fun DrawerMenu(navController: NavHostController, coroutineScope: CoroutineScope, drawerState: DrawerState) {Column {
    Text("Menu")
    Button(onClick = {
        coroutineScope.launch {
            drawerState.close()
        }
        navController.navigate("Tela1")
    }) { Text("Home") }
    Button(onClick = {
        coroutineScope.launch {
            drawerState.close()
        }
        navController.navigate("Tela2")
    }) { Text("Screen 2") }
    Button(onClick = {
        coroutineScope.launch {
            drawerState.close()
        }
        navController.navigate("Tela3")
    }) { Text("Screen 3") }
}
}

