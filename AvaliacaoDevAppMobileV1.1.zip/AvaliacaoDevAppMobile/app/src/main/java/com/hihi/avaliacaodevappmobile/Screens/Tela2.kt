package com.hihi.avaliacaodevappmobile.Screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun Tela2() {
    val frutas = listOf(
        "Maçã" to "R$ 5,00/kg",
        "Banana" to "R$ 3,50/kg",
        "Laranja" to "R$ 4,20/kg",
        "Manga" to "R$ 6,00/kg",
        "Melancia" to "R$ 2,80/kg"
    )

    var selectedFruta by remember { mutableStateOf<Pair<String, String>?>(null) } // Controla a fruta selecionada

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(frutas) { fruta ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedFruta = fruta },
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Text(
                    text = fruta.first,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }

    // Exibe o AlertDialog (modal) quando uma fruta é clicada
    selectedFruta?.let { fruta ->
        AlertDialog(
            onDismissRequest = { selectedFruta = null },
            title = { Text("Preço por kg") },
            text = { Text("O preço de ${fruta.first} é ${fruta.second}.") },
            confirmButton = {
                Button(onClick = { selectedFruta = null }) {
                    Text("Fechar")
                }
            }
        )
    }
}
